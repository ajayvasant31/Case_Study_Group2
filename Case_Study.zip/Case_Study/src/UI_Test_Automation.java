import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import common.Assert;

public class UI_Test_Automation {

	public static void main(String[] args) {

		
		
		System.setProperty("webdriver.chrome.driver","ChromeDriver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		
		driver.get("http://newtours.demoaut.com/mercurysignon.php");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[1]//td[2]//input")).sendKeys("mercury");
		driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[2]//td[2]//input")).sendKeys("mercury");
		driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[4]//td//input")).click();
		
		
		//*****Test step 1*****//
		boolean status = driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[1]//td//img")).isDisplayed();
		
		if(status)
		{
			System.out.println("TEST 1: PASS");
		}
		else
		{	
			System.out.println("TEST 1: FAIL");
			driver.close();
		
		}
		
		Select depart = new Select(driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[4]//td[2]//select")));
	
		Select arrive = new Select(driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[6]//td[2]//select")));
		
		
		depart.selectByVisibleText("London");
		arrive.selectByVisibleText("New York");
		
		
		driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[9]//td[2]//font//font//input[1]")).click();
		
		driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[5]//td//form//table//tbody//tr[14]//td//input")).click();

		
	
		//*****Test step 2*****//
			status = driver.findElement(By.xpath("//html//body//div//table//tbody//tr//td[2]//table//tbody//tr[4]//td//table//tbody//tr//td[2]//table//tbody//tr[1]//td//img")).isDisplayed();
				
				if(status)
				{
					System.out.println("TEST 2 : PASS");
				}
				else
				{	
					System.out.println("TEST 2 : FAIL");
					driver.close();
				
				}

		
				driver.close();
		
	}

}
